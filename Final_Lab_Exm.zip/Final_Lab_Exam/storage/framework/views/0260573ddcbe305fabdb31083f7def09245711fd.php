<?php $__env->startSection('navbar'); ?>
<a href="/app/create">Create New Employee</a> |
<a href="/app/userlist">View Employee List</a> |
<a href="/app/users">Search Employee</a> |
<a href="/app/logout">logout</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH S:\New folder (11)\Final_Lab_Exam\resources\views/layout/navbar.blade.php ENDPATH**/ ?>