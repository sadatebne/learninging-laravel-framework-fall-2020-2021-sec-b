Admin-register new employee,update,search,login,validation,session
Route::resource('/app','AppController');
